import os
from math import sqrt
import numpy as np
import pandas as pd
import cv2
from sklearn.cluster import KMeans
from PIL import Image, ImageDraw, ImageFont
from utils import thermal
from CThermal.CThermal import CFlir
import CThermal.exiftool as exiftool
from colorbar import colorbar


def hotspot_detect(img):
    temp = "static//uploaded//"
    img_x = img
    img = temp + img
    print(img)
    with exiftool.ExifTool() as et:
        metadata = et.get_metadata(img)
        if 'APP1:RawThermalImage' in metadata.keys():
            if len(metadata['APP1:RawThermalImage']) > 0:
                print("True")
                class_obj = CFlir(image_path=img)
        else:
            raise Exception(f'File is not a valid FLIR thermal image: {img}')
            quit()

    thermal_array = class_obj.thermal_np
    _, scaled_thermal_array = class_obj.default_scaling_image(thermal_array)

    img_max_temp = np.max(thermal_array)
    avg_temperature = np.nanmean(thermal_array)
    print("Average Temperature No. 1: ", avg_temperature)

    thermal_array[(thermal_array <= avg_temperature)] = np.nan
    avg_temperature = np.nanmean(thermal_array)
    print("Average Temperature No. 2: ", avg_temperature)

    def calculate_threshold_temperature(avg_temperature, img_max_temp, hotspot_min_temperature=60.0):
        if img_max_temp >= hotspot_min_temperature:
            threshold_temperature = hotspot_min_temperature
        elif img_max_temp < hotspot_min_temperature:
            threshold_temperature = img_max_temp - \
                sqrt(img_max_temp - avg_temperature)
        return threshold_temperature

    threshold_temperature = calculate_threshold_temperature(
        avg_temperature, img_max_temp)
    print("Threshold temperature: ", threshold_temperature)

    thermal_array[(thermal_array <= threshold_temperature)] = np.nan
    thermal_array = np.nan_to_num(thermal_array, nan=0)
    df = pd.DataFrame(thermal_array)
    mean = df.max(axis=1)
    df = df[mean != 0]

    n_samples = df.shape[0]
    n_clusters = int(n_samples / 5)
    n_clusters = n_clusters if n_clusters > 0 else 1

    def create_kmeans_model(n_clusters=3, max_iter=300):
        model = KMeans(n_clusters=n_clusters, max_iter=max_iter)
        print("Model Config:", model)
        return model

    model = create_kmeans_model(n_clusters=n_clusters)
    model = model.fit(df)
    labels = model.labels_
    df = df.copy(deep=True)
    df['clusters'] = labels
    result = df
    hotspots = {}
    temp = []

    for cluster in range(0, n_clusters, 1):
        single = df.loc[df['clusters'] == cluster]
        single = single.to_numpy()
        if len(single) > 0:
            max_temp = np.amax(single)
        if max_temp in thermal_array and max_temp > 0.0:
            index = np.where(thermal_array == max_temp)
            index = np.array([x[0] for x in index])
            location = (index[1], index[0])
            temp.append(max_temp)
            hotspots[f'hotspot_{cluster}'] = {
                'location': f'{location[0]},{location[1]}', 'temperature': max_temp}

    count = 0
    coordinates = []
    list1 = []
    s2 = ''
    for hotspot, data in hotspots.items():
        for key, value in data.items():
            if key == 'location':
                for x in range(len(value)):
                    if value[x] != ',':
                        s1 = str(value[x])
                        s2 += s1
                    else:
                        list1.append(s2)
                        s2 = ''
                list1.append(s2)
                s2 = ''
                coordinates.append((list1[0], list1[1]))
                count += 1
            list1 = []
    txt = []
    for coordinate in coordinates:
        txt.append('S'+coordinate[0])

    out_path = "static//processed//"
    out_file = out_path + img_x
    image = cv2.imread(img, cv2.IMREAD_GRAYSCALE)
    heatmap = cv2.applyColorMap(image, cv2.COLORMAP_PLASMA)
    cbar = colorbar()
    img = cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB)
    heatmap = Image.fromarray(img)
    img_w, img_h = cbar.size
    bg_w, bg_h = heatmap.size
    offset = ((bg_w - img_w) // 1, (bg_h - img_h) // 2)
    heatmap.paste(cbar, offset)
    draw = ImageDraw.Draw(heatmap)
    font = ImageFont.truetype("font.ttf", 16)

    i = j = 10
    for each in txt:
        j += 20
        draw.rectangle(((0, 0), (135, 30)), fill=(0, 0, 0))

    if len(txt) > 1:
        a = 0
        b = 1
        draw.rectangle(((159, 3), (186, 22)), fill=(0, 0, 0))
        draw.text((167, 8), "°C", (255, 255, 255), font=font)
        for each in range(len(txt)):
            if each != len(txt)-1:
                j += 20
            draw.rectangle(((0, 0), (j, j+15)), fill=(0, 0, 0))
    else:
        draw.rectangle(((142, 2), (170, 32)), fill=(0, 0, 0))
        draw.text((150, 8), "°C", (255, 255, 255), font=font)

    i = j = 10
    k = 0
    for each in txt:
        draw.text((i, j), each + "             " +
                  str(temp[k].round(2)), (255, 255, 255), font=font)
        j += 20
        k += 1

    if len(txt) > 1:
        draw.text((i, j), "            ", (255, 255, 255), font=font)
        a = 0
        b = 1
        for each in range(len(txt)):
            if each != len(txt)-1:
                draw.text((i, j+20), txt[each] + " - " + txt[each+1] + "    " + str(
                    (temp[each]-temp[each+1]).round(2)), (255, 255, 255), font=font)
                j += 20

    draw.rectangle(((595, 25), (622, 46)), fill=(0, 0, 0))
    draw.text((600, 30), "80", (255, 255, 255), font=font)
    draw.rectangle(((585, 465), (628, 489)), fill=(0, 0, 0))
    draw.text((590, 470), "-12.7", (255, 255, 255), font=font)
    open_cv_image = np.array(heatmap)
    heatmap = open_cv_image[:, :, ::-1].copy()
    finale = cv2.imwrite(out_file, heatmap)

    def draw_hotspots(coordinates, radius=8, thickness=3, color=(0, 255, 0)):
        inp_draw = Image.open(out_file)
        entry = out_file
        draw = ImageDraw.Draw(inp_draw, 'RGBA')
        radius = 12
        for coordinate in coordinates:
            x, y = int(coordinate[0]), int(coordinate[1])
            txt = 'S'+coordinate[0]
            draw.text((x+7, y-20), txt)
            draw.line([(x, y-radius), (x, y+radius)],
                      fill=color, width=thickness)
            draw.line([(x-radius, y), (x+radius, y)],
                      fill=color, width=thickness)
        os.remove(out_file)
        final_image = inp_draw.save(out_path+img_x[:-4]+'_dc.png')

    count = 0
    coordinates = []
    list1 = []
    s2 = ''
    for hotspot, data in hotspots.items():
        for key, value in data.items():
            if key == 'location':
                for x in range(len(value)):
                    if value[x] != ',':
                        s1 = str(value[x])
                        s2 += s1
                    else:
                        list1.append(s2)
                        s2 = ''
                list1.append(s2)
                s2 = ''
                coordinates.append((list1[0], list1[1]))
                count += 1
            list1 = []
    draw_hotspots(coordinates)

    dic = {}
    dic[img_x[:-4]+'_dc.png'] = out_path+img_x[:-4]+'_dc.png'

    return dic
