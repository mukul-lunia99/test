"""Author: Adib Yahaya
Date: 10/7/2020
Description: Utilily functions for thermal image processing.
"""

import exiftool

def img_isThermal(img):
    """Check if image is FLIR thermal image

    Parameters
    ----------
    img : str
        Path to thermal image

    Returns
    -------
    bool
        [description]
    """
    with exiftool.ExifTool() as et:
        metadata = et.get_metadata(img)
    if 'APP1:RawThermalImage' in metadata.keys():
        if len(metadata['APP1:RawThermalImage']) > 0:
            return True
        else:
            return False
        print('exiftool is working1')
    else:
        print('exiftool is working2')
        return False
