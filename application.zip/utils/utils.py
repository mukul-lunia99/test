"""A set of convenient functions to be used in multiple projects.

Author: Adib Yahaya
Date: 7/29/2020
"""

import logging
import os
import shutil


def delete_file(file_path):
    """Delete a file or a directory recursively.

    Parameters
    ----------
    file_path : str
        File path or directory
    """
    try:
        if os.path.isfile(file_path) or os.path.islink(file_path):
            os.unlink(file_path)
        elif os.path.isdir(file_path):
            shutil.rmtree(file_path)
    except Exception as e:
        logging.error('Failed to delete %s. Reason: %s' % (file_path, e))


def makedir(name, location=None):
    """Make a new directory.

    Parameters
    ----------
    name : str
        Name of the directory. Can also accept this/is/a/directory instead of specifying the location
    location : str, optional
        Specify the location of directory, by default None
    """
    if location:
        try:
            path = os.path.join(location, name)
            os.makedirs(path)
        except FileExistsError:
            # directory already exists
            pass
    else:
        try:
            os.makedirs(name)
        except FileExistsError:
            # directory already exists
            pass


def copyfile(src, dst):
    """Copy a file to a specified location.

    Parameters
    ----------
    src : str
        Path to source file
    dst : str
        Path to destination directory
    """
    try:
        shutil.copy2(src, dst)
    except Exception as e:
        logging.error('Error copying {} to {}: {}'.format(src, dst, e))


def get_dict_item_recursively(search_dict, field):
    """Take a dict with nested lists and dicts, and search all dicts for a key of the field provided.

    Parameters
    ----------
    search_dict : dict
        The dict to be searched
    field : string
        Key to look for

    Returns
    -------
    list
        Values of field's key
    """
    fields_found = []

    for key, value in search_dict.items():

        if key == field:
            fields_found.append(value)

        elif isinstance(value, dict):
            results = get_dict_item_recursively(value, field)
            for result in results:
                fields_found.append(result)

        elif isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    more_results = get_dict_item_recursively(item, field)
                    for another_result in more_results:
                        fields_found.append(another_result)

    return fields_found


def is_directory_empty(dir_path):
    """Check if a directory is empty.

    Parameters
    ----------
    dir_path : str
        Path to directory

    Returns
    -------
    bool
        True if directory is empty, False if otherwise
    """
    if os.path.exists(dir_path) and os.path.isdir(dir_path):
        if not os.listdir(dir_path):
            return True
        else:
            return False
    else:
        logging.warning('Directory doesn\'t exist')
        return False
