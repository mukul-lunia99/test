from flask import *
from werkzeug.utils import secure_filename
import os
from hotspot import hotspot_detect

UPLOAD_FOLDER = 'static/uploaded'
ALLOWED_EXTENSIONS = ['.png', '.jpg', '.jpeg', '.JPG', '.JPEG', '.PNG']

application = Flask(__name__)
application.config['UPLOAD_PATH'] = UPLOAD_FOLDER
application.config['UPLOAD_EXTENSIONS'] = ALLOWED_EXTENSIONS


@application.route('/', methods=['GET', 'POST'])
def uploading():
    if request.method == 'POST':
        counts = request.files.getlist('filepath')
        for count in counts:
            uploaded_file = count
            filename = secure_filename(uploaded_file.filename)
            if filename != '':
                file_ext = os.path.splitext(filename)[1]
                if file_ext not in application.config['UPLOAD_EXTENSIONS']:
                    abort(400)
            uploaded_file.save(os.path.join(
                application.config['UPLOAD_PATH'], count.filename))
        return redirect('/detected')

    return render_template("uploaded.html")


@application.route('/detected', methods=['GET', 'POST'])
def detection():

    path = os.listdir('static\\uploaded')
    dic = {}
    temp_x = {}
    for each in path:
        each = str(each)
        temp_x = hotspot_detect(each)
        dic.update(temp_x)

    redirect("/")
    return render_template("detected.html", values=dic)


if __name__ == '__main__':
    application.run(debug=True)
