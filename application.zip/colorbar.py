import cv2 as cv
import numpy as np
from matplotlib import pyplot as plt
from PIL import Image, ImageOps
from tqdm import tqdm
from logzero import logger

def colorbar():
    cmap=cv.COLORMAP_JET
    cb_gray = np.arange(255, 0, -1, dtype=np.uint8).reshape((255, 1))
    # Resize the colorbar
    cb_width = cb_gray.shape[1] + 0
    cb_height = cb_gray.shape[0] + 150
    dim = (cb_width, cb_height)
    cb_gray = cv.resize(cb_gray, dim)
    cb_color = cv.applyColorMap(cb_gray, cmap)
    
    for i in range(1, 6):
        cb_color = np.concatenate((cb_color, cb_color), axis=1)
        
    append_img = np.zeros((405, cb_color.shape[1]+20, 3), dtype=np.uint8)    
    # Use white background
    append_img[:] = (255,255,255)
    # The horizontal position of the color bar & text
    cb_x_position = 10
    text_x_position = 5
    append_img[append_img.shape[0]//2-cb_color.shape[0]//2:append_img.shape[0]//2 - (cb_color.shape[0]//2) + cb_color.shape[0], cb_x_position:cb_x_position + cb_color.shape[1]] = cb_color
    img = Image.fromarray(append_img)
    
    return img